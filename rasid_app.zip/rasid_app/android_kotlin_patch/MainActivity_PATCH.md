# MainActivity.kt patch (optional but recommended)

The `android:showWhenLocked="true"` + `android:turnScreenOn="true"` manifest
attributes (see AndroidManifest_ADDITIONS.xml) cover most devices on
Android 8.1+. For extra reliability on stricter OEM skins, also set the
same flags programmatically.

Open the generated `android/app/src/main/kotlin/<your/package/path>/MainActivity.kt`
(the exact folder depends on the `--org` you passed to `flutter create`)
and replace its contents with:

```kotlin
package com.example.rasid_app // <-- keep whatever package flutter create generated here

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        keyguardManager.requestDismissKeyguard(this, null)
    }
}
```

Only change the `package` line at the top — keep it identical to whatever
`flutter create` already put in the generated file, or the app won't build.
