import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import 'app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Required once, early, by flutter_foreground_task on the main isolate.
  FlutterForegroundTask.initCommunicationPort();
  runApp(const RasidApp());
}
