import 'dart:io';
import 'dart:math' as math;

import 'package:camera/camera.dart';
import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

import '../models/face_embedding.dart';

enum ScanOutcome { matched, mismatch, noFace, error }

class ScanResult {
  final ScanOutcome outcome;
  final double? similarity;
  const ScanResult(this.outcome, {this.similarity});
}

/// Wraps Google ML Kit's on-device face detector (no network calls, model
/// ships inside the ML Kit library / Play Services) and turns a detected
/// face into a comparable [FaceEmbedding].
///
/// See face_embedding.dart for the honest caveat on matching accuracy.
class FaceEngine {
  FaceEngine._();
  static final FaceEngine instance = FaceEngine._();

  final FaceDetector _detector = FaceDetector(
    options: FaceDetectorOptions(
      performanceMode: FaceDetectorMode.accurate,
      enableLandmarks: true,
      enableContours: false,
      enableClassification: false,
      minFaceSize: 0.25,
    ),
  );

  /// Similarity threshold above which two embeddings are considered the
  /// same person. Tune this after real-world testing — lower is stricter.
  static const double matchThreshold = 0.92;

  Future<InputImage> _inputImageFromFile(XFile file) async {
    return InputImage.fromFilePath(file.path);
  }

  /// Runs detection on a captured frame and returns the best face found,
  /// or null if no face is present (used for both enrollment and the
  /// "camera obscured / no face" background-scan case).
  Future<Face?> detectBestFace(XFile file) async {
    final inputImage = await _inputImageFromFile(file);
    final faces = await _detector.processImage(inputImage);
    if (faces.isEmpty) return null;
    faces.sort((a, b) =>
        (b.boundingBox.width * b.boundingBox.height).compareTo(a.boundingBox.width * a.boundingBox.height));
    return faces.first;
  }

  /// Builds a normalized landmark-distance vector for a detected face.
  /// Every distance is divided by the face bounding-box width so the
  /// vector is roughly scale- and position-invariant.
  FaceEmbedding? embeddingFromFace(Face face) {
    final box = face.boundingBox;
    final w = box.width;
    if (w <= 0) return null;

    Offset? pt(FaceLandmarkType type) {
      final lm = face.landmarks[type];
      if (lm == null) return null;
      return Offset(lm.position.x.toDouble(), lm.position.y.toDouble());
    }

    final leftEye = pt(FaceLandmarkType.leftEye);
    final rightEye = pt(FaceLandmarkType.rightEye);
    final nose = pt(FaceLandmarkType.noseBase);
    final mouthLeft = pt(FaceLandmarkType.leftMouth);
    final mouthRight = pt(FaceLandmarkType.rightMouth);
    final leftEar = pt(FaceLandmarkType.leftEar);
    final rightEar = pt(FaceLandmarkType.rightEar);

    final points = [leftEye, rightEye, nose, mouthLeft, mouthRight, leftEar, rightEar];
    if (points.where((p) => p != null).length < 4) {
      // Not enough landmarks visible (extreme angle / poor lighting) to
      // build a reliable vector.
      return null;
    }

    final vector = <double>[];
    for (var i = 0; i < points.length; i++) {
      for (var j = i + 1; j < points.length; j++) {
        final a = points[i];
        final b = points[j];
        if (a == null || b == null) {
          vector.add(0);
        } else {
          final d = (a - b).distance / w;
          vector.add(d);
        }
      }
    }
    // Also encode head-pose angles — a genuine intruder rarely holds the
    // exact same pose, but this mainly helps reject blank/odd frames.
    vector.add((face.headEulerAngleY ?? 0) / 90.0);
    vector.add((face.headEulerAngleZ ?? 0) / 90.0);

    return FaceEmbedding(vector);
  }

  /// Full pipeline for one background-scan cycle: detect -> embed -> compare.
  Future<ScanResult> scan(XFile capturedFrame, FaceEmbedding ownerEmbedding) async {
    try {
      final face = await detectBestFace(capturedFrame);
      if (face == null) return const ScanResult(ScanOutcome.noFace);

      final embedding = embeddingFromFace(face);
      if (embedding == null) return const ScanResult(ScanOutcome.noFace);

      final similarity = embedding.similarityTo(ownerEmbedding);
      if (similarity >= matchThreshold) {
        return ScanResult(ScanOutcome.matched, similarity: similarity);
      }
      return ScanResult(ScanOutcome.mismatch, similarity: similarity);
    } catch (e) {
      return const ScanResult(ScanOutcome.error);
    }
  }

  Future<void> dispose() async {
    await _detector.close();
  }
}

// Tiny local Offset so this file doesn't need to import dart:ui just for
// one struct (keeps it usable from the background isolate cleanly).
class Offset {
  final double dx, dy;
  const Offset(this.dx, this.dy);
  Offset operator -(Offset other) => Offset(dx - other.dx, dy - other.dy);
  double get distance => math.sqrt(dx * dx + dy * dy);
}
