import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import 'face_engine.dart';
import 'security_protocol.dart';
import 'storage_service.dart';

/// Entry point registered with FlutterForegroundTask.setTaskHandler().
/// Must be a top-level or static function — the plugin spawns it inside
/// its own background isolate.
@pragma('vm:entry-point')
void startCameraScanCallback() {
  FlutterForegroundTask.setTaskHandler(CameraScanTaskHandler());
}

/// Runs entirely in the foreground-service isolate. Every cycle:
///   1. Skip if the owner has an active snooze.
///   2. Grab one still frame from the front camera (no live preview /
///      no continuous video stream — keeps CPU/GPU load low).
///   3. Ask FaceEngine whether it's the enrolled owner.
///   4. On anything other than a confident match, hand the frame to
///      SecurityProtocol to sound the alarm, log it, and surface the
///      full-screen alert.
///
/// NOTE: camera access from a headless background isolate is one of the
/// rougher edges of Android background work — behavior can vary by OEM
/// (Samsung/Xiaomi/etc. aggressively kill background camera sessions
/// unless the app is exempted from battery optimization). Test on your
/// target devices and, if a given OEM kills the session, prompt the user
/// to disable battery optimization for the app (see settings_screen.dart).
class CameraScanTaskHandler extends TaskHandler {
  CameraController? _controller;
  bool _busy = false;

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    try {
      final cameras = await availableCameras();
      final front = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );
      _controller = CameraController(
        front,
        ResolutionPreset.low, // ~320x240-ish, matches the low-res spec
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );
      await _controller!.initialize();
    } catch (e) {
      FlutterForegroundTask.sendDataToMain({'event': 'camera_init_failed', 'error': e.toString()});
    }
  }

  @override
  void onRepeatEvent(DateTime timestamp) {
    // Fire-and-forget async work per tick; onRepeatEvent itself stays sync.
    _runCycle();
  }

  Future<void> _runCycle() async {
    if (_busy) return; // don't overlap cycles if a scan runs long
    _busy = true;
    try {
      final snoozed = await StorageService.instance.isSnoozedNow();
      if (snoozed) {
        FlutterForegroundTask.sendDataToMain({'event': 'tick_snoozed'});
        return;
      }

      final ownerEmbedding = await StorageService.instance.loadOwnerEmbedding();
      if (ownerEmbedding == null) {
        // Not enrolled yet — nothing to compare against.
        return;
      }

      final controller = _controller;
      if (controller == null || !controller.value.isInitialized) {
        await _handleObscuredOrError('camera_obscured');
        return;
      }

      final XFile frame = await controller.takePicture();
      final result = await FaceEngine.instance.scan(frame, ownerEmbedding);

      switch (result.outcome) {
        case ScanOutcome.matched:
          FlutterForegroundTask.sendDataToMain(
            {'event': 'tick_matched', 'similarity': result.similarity},
          );
          break;
        case ScanOutcome.mismatch:
          final bytes = await File(frame.path).readAsBytes();
          await SecurityProtocol.instance.trigger(jpegBytes: bytes, reason: 'mismatch');
          FlutterForegroundTask.sendDataToMain({'event': 'tick_alarm', 'reason': 'mismatch'});
          break;
        case ScanOutcome.noFace:
          await _handleObscuredOrError('no_face');
          break;
        case ScanOutcome.error:
          FlutterForegroundTask.sendDataToMain({'event': 'tick_error'});
          break;
      }

      // Clean up the temp capture file regardless of outcome.
      try {
        await File(frame.path).delete();
      } catch (_) {}
    } finally {
      _busy = false;
    }
  }

  Future<void> _handleObscuredOrError(String reason) async {
    // Per the spec: an unregistered face OR an obscured camera both count
    // as a trigger condition. We still try to log a black/placeholder
    // frame isn't useful, so for "no camera at all" we log without a
    // photo attachment being meaningful — SecurityProtocol handles an
    // empty-ish jpeg gracefully.
    final controller = _controller;
    Uint8List bytes = Uint8List(0);
    try {
      if (controller != null && controller.value.isInitialized) {
        final frame = await controller.takePicture();
        bytes = await File(frame.path).readAsBytes();
        await File(frame.path).delete();
      }
    } catch (_) {}
    await SecurityProtocol.instance.trigger(jpegBytes: bytes, reason: reason);
    FlutterForegroundTask.sendDataToMain({'event': 'tick_alarm', 'reason': reason});
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    await _controller?.dispose();
    _controller = null;
  }

  @override
  void onReceiveData(Object data) {
    // Reserved for main-isolate -> task-isolate messages (e.g. force a
    // manual test cycle). See HomeDashboard's "اختبار الإنذار" button.
    if (data is Map && data['command'] == 'force_alarm_test') {
      _forceTestAlarm();
    }
  }

  Future<void> _forceTestAlarm() async {
    final controller = _controller;
    try {
      Uint8List bytes = Uint8List(0);
      if (controller != null && controller.value.isInitialized) {
        final frame = await controller.takePicture();
        bytes = await File(frame.path).readAsBytes();
        await File(frame.path).delete();
      }
      await SecurityProtocol.instance.trigger(jpegBytes: bytes, reason: 'manual_test');
      FlutterForegroundTask.sendDataToMain({'event': 'tick_alarm', 'reason': 'manual_test'});
    } catch (_) {}
  }

  @override
  void onNotificationButtonPressed(String id) {}

  @override
  void onNotificationPressed() {
    FlutterForegroundTask.launchApp('/');
  }

  @override
  void onNotificationDismissed() {}
}
