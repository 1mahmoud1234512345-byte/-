import 'package:local_auth/local_auth.dart';

import 'storage_service.dart';

/// Every path that can change protection state (snooze, or later a
/// "disable protection" setting) MUST go through here, and this class
/// never skips the biometric/PIN check — that gate is the whole point
/// of the anti-snooping design (an intruder holding the phone should not
/// be able to just tap "pause" and walk away with it disarmed).
class SnoozeController {
  SnoozeController._();
  static final SnoozeController instance = SnoozeController._();

  final LocalAuthentication _auth = LocalAuthentication();

  Future<bool> _authenticate(String reason) async {
    try {
      final canCheck = await _auth.canCheckBiometrics || await _auth.isDeviceSupported();
      if (!canCheck) return false;
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(
          biometricOnly: false, // falls back to device PIN/pattern too
          stickyAuth: true,
        ),
      );
    } catch (_) {
      return false;
    }
  }

  /// Returns true if the snooze was actually applied (i.e. auth succeeded).
  Future<bool> requestSnooze(Duration duration) async {
    final ok = await _authenticate('أكّد هويتك لتأجيل حماية الجهاز');
    if (!ok) return false;
    await StorageService.instance.setSnoozeUntil(DateTime.now().add(duration));
    return true;
  }

  Future<bool> requestCancelSnooze() async {
    final ok = await _authenticate('أكّد هويتك لاستئناف الحماية الآن');
    if (!ok) return false;
    await StorageService.instance.clearSnooze();
    return true;
  }

  /// Gate for opening settings / clearing the log / re-enrolling — anything
  /// an intruder would want to reach for.
  Future<bool> authenticateForSensitiveAction(String reason) => _authenticate(reason);
}
