import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:encrypt/encrypt.dart' as enc;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';

import '../models/face_embedding.dart';
import '../models/intruder_log_entry.dart';

/// Everything durable: the owner's enrolled face, the AES key used to
/// encrypt intruder photos on disk, and the SQLite log of events.
///
/// Design choices:
/// - The AES key itself lives in flutter_secure_storage, which is backed
///   by the Android Keystore — it never touches plain SharedPreferences.
/// - Intruder photos are written to the app's private storage directory
///   as AES-CBC encrypted bytes, never as plain .jpg files.
/// - Only small, non-sensitive flags (onboarding done, snooze-until epoch
///   millis) go in shared_preferences, since the background isolate needs
///   to read them cheaply on every 7-second cycle.
class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  final _secure = const FlutterSecureStorage();
  static const _kOwnerEmbedding = 'owner_face_embedding';
  static const _kAesKey = 'intruder_photo_aes_key';
  static const _kOnboardingDone = 'onboarding_done';
  static const _kSnoozeUntilMillis = 'snooze_until_millis';

  Database? _db;

  Future<Database> get _database async {
    if (_db != null) return _db!;
    final dir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(dir.path, 'rasid_log.db');
    _db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE intruder_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp INTEGER NOT NULL,
            encryptedImagePath TEXT NOT NULL,
            reason TEXT NOT NULL
          )
        ''');
      },
    );
    return _db!;
  }

  // ---------------- Owner enrollment ----------------

  Future<void> saveOwnerEmbedding(FaceEmbedding embedding) async {
    await _secure.write(key: _kOwnerEmbedding, value: embedding.toJsonString());
  }

  Future<FaceEmbedding?> loadOwnerEmbedding() async {
    final raw = await _secure.read(key: _kOwnerEmbedding);
    return FaceEmbedding.fromJsonString(raw);
  }

  Future<bool> hasOwnerEnrolled() async => (await loadOwnerEmbedding()) != null;

  Future<void> clearEnrollment() async => _secure.delete(key: _kOwnerEmbedding);

  // ---------------- Onboarding flag (fast, non-sensitive) ----------------

  Future<void> setOnboardingDone() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kOnboardingDone, true);
  }

  Future<bool> isOnboardingDone() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kOnboardingDone) ?? false;
  }

  // ---------------- Snooze state (read by the background isolate) ----------------

  Future<void> setSnoozeUntil(DateTime until) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kSnoozeUntilMillis, until.millisecondsSinceEpoch);
  }

  Future<void> clearSnooze() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_kSnoozeUntilMillis);
  }

  /// Returns true if scanning should be skipped right now.
  Future<bool> isSnoozedNow() async {
    final prefs = await SharedPreferences.getInstance();
    final millis = prefs.getInt(_kSnoozeUntilMillis);
    if (millis == null) return false;
    final until = DateTime.fromMillisecondsSinceEpoch(millis);
    if (DateTime.now().isAfter(until)) {
      await prefs.remove(_kSnoozeUntilMillis);
      return false;
    }
    return true;
  }

  Future<DateTime?> getSnoozeUntil() async {
    final prefs = await SharedPreferences.getInstance();
    final millis = prefs.getInt(_kSnoozeUntilMillis);
    if (millis == null) return null;
    return DateTime.fromMillisecondsSinceEpoch(millis);
  }

  // ---------------- AES key for intruder photos ----------------

  Future<enc.Key> _getOrCreateAesKey() async {
    final existing = await _secure.read(key: _kAesKey);
    if (existing != null) {
      return enc.Key.fromBase64(existing);
    }
    final key = enc.Key.fromSecureRandom(32); // AES-256
    await _secure.write(key: _kAesKey, value: key.base64);
    return key;
  }

  // ---------------- Intruder log ----------------

  /// Encrypts [jpegBytes] and stores it, then records a log row.
  Future<IntruderLogEntry> saveIntruderEvent({
    required Uint8List jpegBytes,
    required String reason,
  }) async {
    final key = await _getOrCreateAesKey();
    final iv = enc.IV.fromSecureRandom(16);
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final encrypted = encrypter.encryptBytes(jpegBytes, iv: iv);

    final dir = await getApplicationDocumentsDirectory();
    final logsDir = Directory(p.join(dir.path, 'intruder_photos'));
    if (!await logsDir.exists()) await logsDir.create(recursive: true);

    final fileName = 'intruder_${DateTime.now().millisecondsSinceEpoch}.bin';
    final file = File(p.join(logsDir.path, fileName));

    // Store IV + ciphertext together (first 16 bytes = IV).
    final combined = Uint8List.fromList([...iv.bytes, ...encrypted.bytes]);
    await file.writeAsBytes(combined, flush: true);

    final entry = IntruderLogEntry(
      timestamp: DateTime.now(),
      encryptedImagePath: file.path,
      reason: reason,
    );

    final db = await _database;
    final id = await db.insert('intruder_log', entry.toMap());
    return IntruderLogEntry(
      id: id,
      timestamp: entry.timestamp,
      encryptedImagePath: entry.encryptedImagePath,
      reason: entry.reason,
    );
  }

  Future<List<IntruderLogEntry>> loadLog({int limit = 100}) async {
    final db = await _database;
    final rows = await db.query('intruder_log', orderBy: 'timestamp DESC', limit: limit);
    return rows.map(IntruderLogEntry.fromMap).toList();
  }

  Future<Uint8List?> decryptIntruderPhoto(String encryptedImagePath) async {
    final file = File(encryptedImagePath);
    if (!await file.exists()) return null;
    final combined = await file.readAsBytes();
    if (combined.length < 16) return null;

    final ivBytes = combined.sublist(0, 16);
    final cipherBytes = combined.sublist(16);

    final key = await _getOrCreateAesKey();
    final iv = enc.IV(Uint8List.fromList(ivBytes));
    final encrypter = enc.Encrypter(enc.AES(key, mode: enc.AESMode.cbc));
    final decrypted = encrypter.decryptBytes(enc.Encrypted(Uint8List.fromList(cipherBytes)), iv: iv);
    return Uint8List.fromList(decrypted);
  }

  Future<void> deleteLogEntry(IntruderLogEntry entry) async {
    final db = await _database;
    await db.delete('intruder_log', where: 'id = ?', whereArgs: [entry.id]);
    final file = File(entry.encryptedImagePath);
    if (await file.exists()) await file.delete();
  }

  Future<void> clearAllLogs() async {
    final db = await _database;
    final rows = await db.query('intruder_log');
    for (final row in rows) {
      final file = File(row['encryptedImagePath'] as String);
      if (await file.exists()) await file.delete();
    }
    await db.delete('intruder_log');
  }
}

/// Small helper so other files can base64-encode without pulling
/// dart:convert everywhere.
String bytesToBase64(Uint8List bytes) => base64Encode(bytes);
