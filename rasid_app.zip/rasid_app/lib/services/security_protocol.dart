import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import 'storage_service.dart';

/// Everything that happens the moment the background scan decides "this is
/// not the owner": sound the alarm, push a full-screen alert, and log the
/// event with an encrypted photo.
///
/// REALITY CHECK (carried over from the app design discussion): Android
/// does not let a normal app force `lockNow()` without Device-Admin /
/// Device Policy Controller privileges, which Google Play restricts
/// heavily for good reason. What we CAN do reliably:
///   1. Play a loud alarm-stream sound that ignores the ringer/DND volume
///      slider (STREAM_ALARM), via AudioContext below.
///   2. Fire a full-screen-intent notification, the same mechanism
///      Android uses for incoming calls and real alarm clocks — it can
///      draw over the lock screen and interrupt whatever the intruder is
///      doing, even though it isn't a true OS-level re-lock.
///   3. Silently save an encrypted photo + timestamp to the log.
class SecurityProtocol {
  SecurityProtocol._();
  static final SecurityProtocol instance = SecurityProtocol._();

  final AudioPlayer _player = AudioPlayer();
  bool _sirenPlaying = false;

  Future<void> _configureAlarmStream() async {
    // Route playback to the ALARM stream so it plays at max volume and
    // ignores the ringer/notification silent switch and most DND profiles.
    await _player.setAudioContext(
      AudioContext(
        android: AudioContextAndroid(
          isSpeakerphoneOn: true,
          stayAwake: true,
          contentType: AndroidContentType.sonification,
          usageType: AndroidUsageType.alarm,
          audioFocus: AndroidAudioFocus.gainTransient,
        ),
      ),
    );
  }

  Future<void> startSiren() async {
    if (_sirenPlaying) return;
    _sirenPlaying = true;
    await _configureAlarmStream();
    await _player.setReleaseMode(ReleaseMode.loop);
    await _player.setVolume(1.0);
    await _player.play(AssetSource('sounds/siren.wav'));
  }

  Future<void> stopSiren() async {
    if (!_sirenPlaying) return;
    _sirenPlaying = false;
    await _player.stop();
  }

  /// Called from the background isolate (the foreground-task handler) the
  /// instant a scan cycle comes back as "not the owner".
  ///
  /// [reason] is one of: no_face | mismatch | camera_obscured | manual_test
  Future<void> trigger({
    required Uint8List jpegBytes,
    required String reason,
  }) async {
    await StorageService.instance.saveIntruderEvent(jpegBytes: jpegBytes, reason: reason);
    await startSiren();

    // Update the persistent notification so it reflects the alert and
    // tapping it opens the app straight to the full-screen alert route.
    FlutterForegroundTask.updateService(
      notificationTitle: 'راصد — تنبيه أمني',
      notificationText: 'تم رصد وجه غير مسجّل. اضغط لفتح شاشة الإنذار.',
    );

    // Bring the Flutter app to the foreground over the lock screen. The
    // native side (MainActivity) is configured with setShowWhenLocked /
    // setTurnScreenOn — see android_kotlin_patch/MainActivity.kt.
    FlutterForegroundTask.launchApp('/alert');

    // Also notify the main isolate/UI directly if it's already alive.
    FlutterForegroundTask.sendDataToMain({'event': 'alarm_triggered', 'reason': reason});
  }

  Future<void> resolveAlarm() async {
    await stopSiren();
    FlutterForegroundTask.updateService(
      notificationTitle: 'راصد',
      notificationText: 'الحماية نشطة — يتم الفحص كل 7 ثوانٍ',
    );
  }
}
