import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../models/intruder_log_entry.dart';
import '../services/snooze_controller.dart';
import '../services/storage_service.dart';

class LogScreen extends StatefulWidget {
  const LogScreen({super.key});

  @override
  State<LogScreen> createState() => _LogScreenState();
}

class _LogScreenState extends State<LogScreen> {
  List<IntruderLogEntry> _entries = [];
  bool _loading = true;

  static const _reasonLabels = {
    'mismatch': 'وجه غير مطابق',
    'no_face': 'لا يوجد وجه ظاهر',
    'camera_obscured': 'الكاميرا محجوبة',
    'manual_test': 'اختبار يدوي',
  };

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await StorageService.instance.loadLog();
    setState(() {
      _entries = entries;
      _loading = false;
    });
  }

  Future<void> _clearAll() async {
    final ok = await SnoozeController.instance.authenticateForSensitiveAction(
      'أكّد هويتك لمسح السجلّ بالكامل',
    );
    if (!ok) return;
    await StorageService.instance.clearAllLogs();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF14130F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF14130F),
        title: const Text('سجلّ المحاولات', style: TextStyle(color: Color(0xFFF2EFE6))),
        iconTheme: const IconThemeData(color: Color(0xFFF2EFE6)),
        actions: [
          if (_entries.isNotEmpty)
            IconButton(icon: const Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: _clearAll),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _entries.isEmpty
              ? const Center(
                  child: Text('لا توجد محاولات مسجّلة حتى الآن.',
                      style: TextStyle(color: Color(0xFFA39C89))),
                )
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _entries.length,
                  itemBuilder: (context, i) => _LogTile(entry: _entries[i]),
                ),
    );
  }
}

class _LogTile extends StatelessWidget {
  final IntruderLogEntry entry;
  const _LogTile({required this.entry});

  static const _reasonLabels = {
    'mismatch': 'وجه غير مطابق',
    'no_face': 'لا يوجد وجه ظاهر',
    'camera_obscured': 'الكاميرا محجوبة',
    'manual_test': 'اختبار يدوي',
  };

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List?>(
      future: StorageService.instance.decryptIntruderPhoto(entry.encryptedImagePath),
      builder: (context, snapshot) {
        final bytes = snapshot.data;
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: const Color(0xFF1E1C16),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: const Color(0xFF3A3527)),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: SizedBox(
                  width: 52,
                  height: 52,
                  child: bytes != null && bytes.isNotEmpty
                      ? Image.memory(bytes, fit: BoxFit.cover)
                      : Container(
                          color: const Color(0xFF211F18),
                          child: const Icon(Icons.no_photography_outlined, color: Color(0xFFA39C89), size: 20),
                        ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_reasonLabels[entry.reason] ?? entry.reason,
                        style: const TextStyle(color: Color(0xFFE23B2E), fontWeight: FontWeight.w600, fontSize: 13.5)),
                    const SizedBox(height: 2),
                    Text(
                      '${entry.timestamp.year}/${entry.timestamp.month.toString().padLeft(2, '0')}/${entry.timestamp.day.toString().padLeft(2, '0')} — ${entry.timestamp.hour.toString().padLeft(2, '0')}:${entry.timestamp.minute.toString().padLeft(2, '0')}:${entry.timestamp.second.toString().padLeft(2, '0')}',
                      style: const TextStyle(color: Color(0xFFA39C89), fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
