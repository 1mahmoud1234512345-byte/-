import 'package:flutter/material.dart';

import '../services/security_protocol.dart';
import '../services/snooze_controller.dart';

/// Shown full-screen, on top of the lock screen when possible (see
/// MainActivity.kt patch for setShowWhenLocked/setTurnScreenOn), the
/// moment SecurityProtocol.trigger() fires. Dismissing it requires
/// biometric/PIN auth so an intruder can't just tap it away.
class AlertScreen extends StatefulWidget {
  const AlertScreen({super.key});

  @override
  State<AlertScreen> createState() => _AlertScreenState();
}

class _AlertScreenState extends State<AlertScreen> with SingleTickerProviderStateMixin {
  bool _resolving = false;

  Future<void> _resolve() async {
    if (_resolving) return;
    setState(() => _resolving = true);
    final ok = await SnoozeController.instance.authenticateForSensitiveAction(
      'أكّد هويتك لإيقاف الإنذار',
    );
    if (ok) {
      await SecurityProtocol.instance.resolveAlarm();
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } else {
      setState(() => _resolving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false, // block the back button — must resolve via biometric
      child: Scaffold(
        backgroundColor: const Color(0xFFC0392B),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.warning_amber_rounded, color: Color(0xFF2A0A06), size: 72),
                const SizedBox(height: 20),
                const Text(
                  'تنبيه: وجه غير مسجّل',
                  style: TextStyle(color: Color(0xFF2A0A06), fontSize: 22, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 10),
                const Text(
                  'تم رصد شخص غير مصرح له بجانب الجهاز، وتم حفظ صورة الحادثة في السجلّ المشفّر.',
                  style: TextStyle(color: Color(0xFF2A0A06), fontSize: 14, height: 1.7),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 40),
                ElevatedButton(
                  onPressed: _resolving ? null : _resolve,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF2A0A06),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(_resolving ? 'جارٍ التحقق…' : 'التحقق ببصمتي لإيقاف الإنذار'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
