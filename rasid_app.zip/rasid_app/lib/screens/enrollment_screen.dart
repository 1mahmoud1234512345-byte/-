import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

import '../services/face_engine.dart';
import '../services/storage_service.dart';

class EnrollmentScreen extends StatefulWidget {
  final VoidCallback onDone;
  const EnrollmentScreen({super.key, required this.onDone});

  @override
  State<EnrollmentScreen> createState() => _EnrollmentScreenState();
}

class _EnrollmentScreenState extends State<EnrollmentScreen> {
  CameraController? _controller;
  bool _initializing = true;
  bool _capturing = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _setup();
  }

  Future<void> _setup() async {
    try {
      final cameras = await availableCameras();
      final front = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.front,
        orElse: () => cameras.first,
      );
      final controller = CameraController(front, ResolutionPreset.medium, enableAudio: false);
      await controller.initialize();
      setState(() {
        _controller = controller;
        _initializing = false;
      });
    } catch (e) {
      setState(() {
        _error = 'تعذّر تشغيل الكاميرا الأمامية. تأكد من منح إذن الكاميرا من إعدادات النظام.';
        _initializing = false;
      });
    }
  }

  Future<void> _captureAndEnroll() async {
    final controller = _controller;
    if (controller == null || _capturing) return;
    setState(() => _capturing = true);
    try {
      final file = await controller.takePicture();
      final face = await FaceEngine.instance.detectBestFace(file);
      if (face == null) {
        _showMessage('لم يتم العثور على وجه واضح. تأكد من الإضاءة والنظر مباشرة للكاميرا.');
        return;
      }
      final embedding = FaceEngine.instance.embeddingFromFace(face);
      if (embedding == null) {
        _showMessage('لم نتمكن من قراءة ملامح الوجه بدقة كافية. جرّب مرة أخرى بإضاءة أفضل.');
        return;
      }
      await StorageService.instance.saveOwnerEmbedding(embedding);
      await StorageService.instance.setOnboardingDone();
      widget.onDone();
    } finally {
      if (mounted) setState(() => _capturing = false);
    }
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF14130F),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 12),
              const Text(
                'تسجيل وجه المالك',
                style: TextStyle(color: Color(0xFFF2EFE6), fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'هذه اللقطة تُستخدم فقط لمقارنة الوجوه محليًا على جهازك، ولا تُرفع لأي خادم خارجي.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFFA39C89), fontSize: 13, height: 1.6),
              ),
              const SizedBox(height: 24),
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    color: const Color(0xFF211F18),
                    child: _initializing
                        ? const Center(child: CircularProgressIndicator())
                        : _error != null
                            ? Center(
                                child: Padding(
                                  padding: const EdgeInsets.all(20),
                                  child: Text(_error!,
                                      textAlign: TextAlign.center,
                                      style: const TextStyle(color: Colors.redAccent)),
                                ),
                              )
                            : CameraPreview(_controller!),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: (_initializing || _error != null || _capturing) ? null : _captureAndEnroll,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF0A202),
                    foregroundColor: const Color(0xFF1B1204),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(_capturing ? 'جارٍ الحفظ…' : 'التقاط وحفظ وجهي',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
