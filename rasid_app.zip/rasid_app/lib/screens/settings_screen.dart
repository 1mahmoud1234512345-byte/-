import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';

import '../services/snooze_controller.dart';
import '../services/storage_service.dart';
import 'enrollment_screen.dart';

/// Every action here is reachable only after a biometric/PIN check —
/// settings are exactly what an intruder would try to reach first.
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _reEnroll(BuildContext context) async {
    final ok = await SnoozeController.instance.authenticateForSensitiveAction(
      'أكّد هويتك لإعادة تسجيل وجه المالك',
    );
    if (!ok) return;
    await StorageService.instance.clearEnrollment();
    if (!context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EnrollmentScreen(onDone: () => Navigator.pop(context)),
      ),
    );
  }

  Future<void> _openBatterySettings(BuildContext context) async {
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('التطبيق مُستثنى بالفعل من تحسين البطارية.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF14130F),
      appBar: AppBar(
        backgroundColor: const Color(0xFF14130F),
        title: const Text('الإعدادات', style: TextStyle(color: Color(0xFFF2EFE6))),
        iconTheme: const IconThemeData(color: Color(0xFFF2EFE6)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _tile(
            context,
            icon: Icons.face_retouching_natural,
            title: 'إعادة تسجيل وجه المالك',
            subtitle: 'استبدال البصمة الوجهية المحفوظة حاليًا',
            onTap: () => _reEnroll(context),
          ),
          _tile(
            context,
            icon: Icons.battery_charging_full,
            title: 'استثناء التطبيق من تحسين البطارية',
            subtitle: 'ضروري كي لا يوقف النظام الفحص في الخلفية على بعض الأجهزة',
            onTap: () => _openBatterySettings(context),
          ),
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'بعض الشركات المصنّعة (سامسونج، شاومي، هواوي وغيرها) تُغلق الخدمات الخلفية بقوة رغم هذا الإعداد. إن توقفت الحماية بشكل متكرر، ابحث عن اسم جهازك مع "background app kill" لمعرفة الخطوة الإضافية المطلوبة على طرازك.',
              style: TextStyle(color: Color(0xFF6E6656), fontSize: 12, height: 1.7),
            ),
          ),
        ],
      ),
    );
  }

  Widget _tile(BuildContext context,
      {required IconData icon, required String title, required String subtitle, required VoidCallback onTap}) {
    return Card(
      color: const Color(0xFF1E1C16),
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFFF0A202)),
        title: Text(title, style: const TextStyle(color: Color(0xFFF2EFE6))),
        subtitle: Text(subtitle, style: const TextStyle(color: Color(0xFFA39C89), fontSize: 12)),
        onTap: onTap,
      ),
    );
  }
}
