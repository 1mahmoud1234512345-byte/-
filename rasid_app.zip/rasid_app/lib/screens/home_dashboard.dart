import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:permission_handler/permission_handler.dart';

import '../services/camera_scan_service.dart';
import '../services/security_protocol.dart';
import '../services/snooze_controller.dart';
import '../services/storage_service.dart';
import 'log_screen.dart';
import 'settings_screen.dart';

class HomeDashboard extends StatefulWidget {
  const HomeDashboard({super.key});

  @override
  State<HomeDashboard> createState() => _HomeDashboardState();
}

class _HomeDashboardState extends State<HomeDashboard> with WidgetsBindingObserver {
  bool _protectionOn = false;
  bool _busy = false;
  String _statusLine = 'الحماية متوقفة';
  DateTime? _snoozeUntil;
  Timer? _uiTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    FlutterForegroundTask.addTaskDataCallback(_onTaskData);
    _refreshSnoozeState();
    _uiTimer = Timer.periodic(const Duration(seconds: 1), (_) => _refreshSnoozeState());
    _checkRunningState();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    FlutterForegroundTask.removeTaskDataCallback(_onTaskData);
    _uiTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkRunningState() async {
    final running = await FlutterForegroundTask.isRunningService;
    setState(() {
      _protectionOn = running;
      _statusLine = running ? 'الحماية نشطة — الفحص كل 7 ثوانٍ' : 'الحماية متوقفة';
    });
  }

  Future<void> _refreshSnoozeState() async {
    final until = await StorageService.instance.getSnoozeUntil();
    if (mounted) setState(() => _snoozeUntil = until);
  }

  void _onTaskData(Object data) {
    if (data is! Map) return;
    switch (data['event']) {
      case 'tick_matched':
        setState(() => _statusLine = 'آخر فحص: تم التعرف على المالك');
        break;
      case 'tick_alarm':
        setState(() => _statusLine = 'إنذار نشط — تحقّق من السجلّ');
        break;
      case 'tick_snoozed':
        setState(() => _statusLine = 'الحماية مؤجّلة مؤقتًا');
        break;
      case 'camera_init_failed':
        setState(() => _statusLine = 'تعذّر تشغيل الكاميرا في الخلفية');
        break;
    }
  }

  Future<bool> _ensurePermissions() async {
    final statuses = await [
      Permission.camera,
      Permission.notification,
    ].request();
    final cameraOk = statuses[Permission.camera]?.isGranted ?? false;
    if (!cameraOk) {
      _snack('إذن الكاميرا مطلوب لعمل الحماية.');
      return false;
    }
    // Foreground-service + ignore-battery-optimizations prompts (Android
    // will show its own system dialog for these two).
    if (await FlutterForegroundTask.checkNotificationPermission() !=
        NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
    return true;
  }

  Future<void> _startProtection() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final ok = await _ensurePermissions();
      if (!ok) return;

      FlutterForegroundTask.initCommunicationPort();
      FlutterForegroundTask.init(
        androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'rasid_protection_channel',
          channelName: 'حماية راصد',
          channelDescription: 'إشعار دائم يعكس حالة الحماية الحالية',
          onlyAlertOnce: true,
        ),
        iosNotificationOptions: const IOSNotificationOptions(),
        foregroundTaskOptions: ForegroundTaskOptions(
          eventAction: ForegroundTaskEventAction.repeat(7000), // 7-second cycle
          autoRunOnBoot: true,
          allowWakeLock: true,
          allowWifiLock: false,
        ),
      );

      await FlutterForegroundTask.startService(
        notificationTitle: 'راصد',
        notificationText: 'الحماية نشطة — يتم الفحص كل 7 ثوانٍ',
        callback: startCameraScanCallback,
      );

      setState(() {
        _protectionOn = true;
        _statusLine = 'الحماية نشطة — الفحص كل 7 ثوانٍ';
      });
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _stopProtection() async {
    final ok = await SnoozeController.instance.authenticateForSensitiveAction(
      'أكّد هويتك لإيقاف الحماية نهائيًا',
    );
    if (!ok) {
      _snack('لم يتم التحقق من الهوية — ما زالت الحماية نشطة.');
      return;
    }
    await FlutterForegroundTask.stopService();
    await SecurityProtocol.instance.resolveAlarm();
    setState(() {
      _protectionOn = false;
      _statusLine = 'الحماية متوقفة';
    });
  }

  Future<void> _snoozeFlow(Duration duration, String label) async {
    final ok = await SnoozeController.instance.requestSnooze(duration);
    if (ok) {
      _snack('تم تأجيل الحماية لمدة $label.');
      _refreshSnoozeState();
    } else {
      _snack('فشل التحقق من الهوية — لم يتم التأجيل.');
    }
  }

  Future<void> _cancelSnooze() async {
    final ok = await SnoozeController.instance.requestCancelSnooze();
    if (ok) {
      _snack('تم استئناف الحماية.');
      _refreshSnoozeState();
    }
  }

  void _testAlarm() {
    if (!_protectionOn) {
      _snack('فعّل الحماية أولاً.');
      return;
    }
    FlutterForegroundTask.sendDataToTask({'command': 'force_alarm_test'});
    _snack('تم إرسال أمر اختبار — الإنذار سيصدر خلال لحظات.');
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    final snoozed = _snoozeUntil != null && _snoozeUntil!.isAfter(DateTime.now());

    return Scaffold(
      backgroundColor: const Color(0xFF14130F),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('راصد',
                      style: TextStyle(color: Color(0xFFF2EFE6), fontSize: 24, fontWeight: FontWeight.bold)),
                  IconButton(
                    icon: const Icon(Icons.settings_outlined, color: Color(0xFFA39C89)),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const SettingsScreen()),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFF1E1C16),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFF3A3527)),
                ),
                child: Column(
                  children: [
                    Icon(
                      _protectionOn ? Icons.shield : Icons.shield_outlined,
                      color: snoozed ? Colors.grey : (_protectionOn ? const Color(0xFFF0A202) : Colors.grey),
                      size: 56,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      snoozed ? 'الحماية مؤجّلة' : _statusLine,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Color(0xFFF2EFE6), fontSize: 15),
                    ),
                    if (snoozed) ...[
                      const SizedBox(height: 6),
                      Text(
                        'سيُستأنف الفحص تلقائيًا الساعة ${_snoozeUntil!.hour.toString().padLeft(2, '0')}:${_snoozeUntil!.minute.toString().padLeft(2, '0')}',
                        style: const TextStyle(color: Color(0xFFA39C89), fontSize: 12),
                      ),
                      TextButton(onPressed: _cancelSnooze, child: const Text('استئناف الآن')),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                height: 52,
                child: ElevatedButton(
                  onPressed: _busy ? null : (_protectionOn ? _stopProtection : _startProtection),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _protectionOn ? const Color(0xFF3A3527) : const Color(0xFFF0A202),
                    foregroundColor: _protectionOn ? const Color(0xFFF2EFE6) : const Color(0xFF1B1204),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(_protectionOn ? 'إيقاف الحماية' : 'تفعيل الحماية',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _protectionOn && !snoozed
                          ? () => _showSnoozeSheet(context)
                          : null,
                      child: const Text('تأجيل الحماية'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _protectionOn ? _testAlarm : null,
                      child: const Text('اختبار الإنذار'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () =>
                    Navigator.push(context, MaterialPageRoute(builder: (_) => const LogScreen())),
                icon: const Icon(Icons.history),
                label: const Text('سجلّ المحاولات'),
              ),
              const Spacer(),
              const Text(
                'ملاحظة: القفل الحقيقي للجهاز غير متاح لتطبيقات الطرف الثالث بدون صلاحيات مدير جهاز؛ يعتمد هذا التطبيق على تنبيه بملء الشاشة وصفارة إنذار بدلاً من ذلك.',
                style: TextStyle(color: Color(0xFF6E6656), fontSize: 11, height: 1.6),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnoozeSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1C16),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('اختر مدة التأجيل', style: TextStyle(color: Color(0xFFF2EFE6), fontSize: 16)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _durationChip(context, const Duration(minutes: 5), '5 دقائق'),
                _durationChip(context, const Duration(minutes: 15), '15 دقيقة'),
                _durationChip(context, const Duration(minutes: 30), '30 دقيقة'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _durationChip(BuildContext context, Duration d, String label) {
    return ActionChip(
      label: Text(label),
      onPressed: () {
        Navigator.pop(context);
        _snoozeFlow(d, label);
      },
    );
  }
}
