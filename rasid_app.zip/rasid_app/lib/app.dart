import 'package:flutter/material.dart';

import 'screens/alert_screen.dart';
import 'screens/enrollment_screen.dart';
import 'screens/home_dashboard.dart';
import 'services/storage_service.dart';

class RasidApp extends StatelessWidget {
  const RasidApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'راصد',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF14130F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFF0A202),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
      ),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child!),
      initialRoute: '/',
      routes: {
        '/': (context) => const _RootGate(),
        '/alert': (context) => const AlertScreen(),
      },
    );
  }
}

/// Decides whether to show onboarding (face enrollment) or the dashboard.
class _RootGate extends StatefulWidget {
  const _RootGate();

  @override
  State<_RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<_RootGate> {
  bool? _enrolled;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final done = await StorageService.instance.hasOwnerEnrolled();
    setState(() => _enrolled = done);
  }

  @override
  Widget build(BuildContext context) {
    if (_enrolled == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!_enrolled!) {
      return EnrollmentScreen(onDone: () => setState(() => _enrolled = true));
    }
    return const HomeDashboard();
  }
}
