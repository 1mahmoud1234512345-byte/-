import 'dart:convert';

/// A lightweight, on-device "embedding" describing a face.
///
/// NOTE ON ACCURACY: this v1 implementation does NOT use a trained
/// face-recognition neural network (e.g. MobileFaceNet / FaceNet).
/// Bundling a real recognition model means shipping a multi-MB .tflite
/// file and a proper 128-d/512-d embedding pipeline, which is out of
/// scope for a first offline pass. Instead, [FaceEngine] builds this
/// vector from normalized distances between ML Kit's face landmarks
/// (eyes, nose, mouth, ears) relative to face width — good enough to
/// tell "same rough facial geometry" from "clearly different face" in
/// good lighting, but it is NOT robust to twins, disguises, or poor
/// lighting the way a trained embedding model would be.
///
/// To upgrade later: drop a MobileFaceNet .tflite file into
/// assets/models/, wire it up in FaceEngine.computeEmbedding() via
/// tflite_flutter, and keep this class's serialize/compare contract
/// the same so nothing else needs to change.
class FaceEmbedding {
  final List<double> vector;

  const FaceEmbedding(this.vector);

  String toJsonString() => jsonEncode(vector);

  static FaceEmbedding? fromJsonString(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final list = (jsonDecode(raw) as List).map((e) => (e as num).toDouble()).toList();
      return FaceEmbedding(list);
    } catch (_) {
      return null;
    }
  }

  /// Cosine similarity in [-1, 1]; 1 means identical direction.
  double similarityTo(FaceEmbedding other) {
    if (vector.length != other.vector.length || vector.isEmpty) return -1;
    double dot = 0, normA = 0, normB = 0;
    for (var i = 0; i < vector.length; i++) {
      dot += vector[i] * other.vector[i];
      normA += vector[i] * vector[i];
      normB += other.vector[i] * other.vector[i];
    }
    if (normA == 0 || normB == 0) return -1;
    return dot / (_sqrt(normA) * _sqrt(normB));
  }

  static double _sqrt(double v) {
    if (v <= 0) return 0;
    double x = v, y = 1;
    const e = 0.0000001;
    while (x - y > e) {
      x = (x + y) / 2;
      y = v / x;
    }
    return x;
  }
}
