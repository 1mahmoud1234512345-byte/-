class IntruderLogEntry {
  final int? id;
  final DateTime timestamp;
  final String encryptedImagePath; // path to the AES-encrypted .bin file on disk
  final String reason; // "no_face" | "mismatch" | "camera_obscured" | "manual_test"

  IntruderLogEntry({
    this.id,
    required this.timestamp,
    required this.encryptedImagePath,
    required this.reason,
  });

  Map<String, Object?> toMap() => {
        'id': id,
        'timestamp': timestamp.millisecondsSinceEpoch,
        'encryptedImagePath': encryptedImagePath,
        'reason': reason,
      };

  static IntruderLogEntry fromMap(Map<String, Object?> map) => IntruderLogEntry(
        id: map['id'] as int?,
        timestamp: DateTime.fromMillisecondsSinceEpoch(map['timestamp'] as int),
        encryptedImagePath: map['encryptedImagePath'] as String,
        reason: map['reason'] as String,
      );
}
